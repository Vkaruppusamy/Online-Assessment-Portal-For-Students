## Online Examination System Project in PHP

- Name of Project:     Online Examination System Project
- Language:            PHP
- Databases used:      My SQL
- Design used:         HTML JavaScript, Ajax, JQuery, Bootstrap
- Browser used:        IE8, Google Chrome, Opera Mozilla
- Software used:        WAMP/ XAMPP/ LAMP/MAMP / Laragon

Manage Course
- Course
- Course Manage
Manage Exam
- Exam
- Manage Examinee
- Add Examinee
- Manage Examinee
Reports
- Report Examinee
- Feedbacks
Dashboard: Examiner All Exam
- Approved by Admin
- Exam Again
Feedbacks
- Feedback Adds

### How to setup this project
- Step 1st. Download xampp / Laragon and Install
- Step 2nd. Text editor notepad++ or Sublime / Vs Code
- Step 3rd. Download the zip file/ Download winrar
- Step 4th. Extract the file and copy “Download Folder” folder
- Step 5th. Paste inside root directory/ where you install xampp/ Laragon local disk C: drive D: drive E: paste: for xampp/htdocs,
- Step 6th. Open PHPMyAdmin http://localhost/phpmyadmin
- Step 7th. Create database name "ccbd_online_exam"
- Step 8th. Import "ccbd_online_exam.sql" file given inside the zip package in SQL file folder
- Step 9th. Run the script http://localhost/"Folder"
- Step 10th. Admin Panel to Go -> "http://localhost/'Folder Location'/adminpanal/admin"
- Step 11th. Login Admin Panel / Student Panel.

### Admin Panel And Student Panel Login Info

admin Username: ccbd <br> Password: <a href="#">Watch This Video</a>

user Username: user <br> Password: <a href="#">Watch This Video</a>

## Admin Panel

 <img src="screenshort/login.png">
 <br>
 <img src="screenshort/dashbord.png">
