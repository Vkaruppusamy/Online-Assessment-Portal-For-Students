
    </div>




        </div>
    </div>
                <marquee onmouseover="this.stop()" onmouseout="this.start()">Hello <a href="https://www.youtube.com/@codecampbdofficial">Code Camp BD</a> family. The sole owner of this code is <a href="https://www.youtube.com/@codecampbdofficial">Code Camp BD</a>. So it is not suitable for any commercial purpose or sale. So you will be instructed to use it for education. And you can message or <a href="https://api.whatsapp.com/send/?phone=01608445456&amp;text&amp;type=phone_number&amp;app_absent=0">WhatsApp</a> to do any kind of project. Also, don't forget to <a href="https://www.youtube.com/@codecampbdofficial">Subscrib</a> to our channel to get all our new videos.</marquee>


</body>
</html>

<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
<script type="text/javascript" src="./assets/scripts/main.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/myjs.js"></script>
<script type="text/javascript" src="js/ajax.js"></script>
<script type="text/javascript" src="js/sweetalert.js"></script>
<!-- <script type="text/javascript" src="js/myjs.js"></script> -->




